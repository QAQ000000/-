<?php
include './includes/common.php';

$out_trade_no = $_POST['out_trade_no'];
$type = $_POST['type'];

$name = getCardType($type);
$ret = $DB->query("update `order` set `type`='{$name}' where `out_trade_no`='{$out_trade_no}'");
if($ret) {
    exit(json_encode(['code'=>1,'msg'=>'succ']));
}