DROP TABLE IF EXISTS `pre_config`;
create table `pre_config` (
`k` varchar(32) NOT NULL,
`v` text NULL,
PRIMARY KEY  (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `pre_config` VALUES ('admin_user', 'admin');
INSERT INTO `pre_config` VALUES ('admin_pwd', '123456');
INSERT INTO `pre_config` VALUES ('template', 'index1');
INSERT INTO `pre_config` VALUES ('sitename', '网络灵堂');
INSERT INTO `pre_config` VALUES ('title', '网络灵堂-葬礼现场');
INSERT INTO `pre_config` VALUES ('keywords', '6');
INSERT INTO `pre_config` VALUES ('description', '死者安息');
INSERT INTO `pre_config` VALUES ('szqq', '死者QQ');
INSERT INTO `pre_config` VALUES ('szmz', '死者名字');
INSERT INTO `pre_config` VALUES ('music', '葬礼音乐外链');
DROP TABLE IF EXISTS `pre_cache`;
create table `pre_cache` (
  `k` varchar(32) NOT NULL,
  `v` longtext NULL,
  `expire` int(11) NOT NULL DEFAULT '0',
PRIMARY KEY  (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




